#include<iostream>
#include<cstring>
using namespace std;

void menu();
void pedir_opciones(int *&op);
void calcular(int *&op, int *&c);

struct equipo{
    char nom[100];
    float part_gana;
    float part_per;
    float par_emp;
    float porcen;
    int dife;
    int puntos;
};

int main(){
    int *opcion = new int;
    int *cant = new int;

    do{
        menu();
        pedir_opciones(opcion);
        calcular(opcion, cant);
    }while(*opcion!=3);

    delete opcion;
    delete cant;	
    return 0;
}

void menu(){
    cout<<"#......MENU......#"<<endl;
    cout<<"1...Ingresar datos..." <<endl;
    cout<<"2...Mostrar datos..." <<endl;
    cout<<"3...SALIR DEL PROGRAMA..." <<endl;
    return;
}

void pedir_opciones(int *&op){
    do{
        cout<<"Ingrese una opcion: ";
        cin>>*op;
        if(*op<1 || *op>3){
            cout<<"Error...";
        }
    }while(*op<1 || *op>3);
    return;
}

void calcular(int *&op, int*&c){
    equipo *equi = new equipo[20];
    int *gol_afa = new int;
    *gol_afa = 0;
    int *gol_en = new int;
    *gol_en = 0;

    int *gol_afato = new int;
    *gol_afato = 0;
    int *gol_ento = new int;
    *gol_ento = 0;

    switch(*op){
        case 1:
            do{
                cout<<"Ingrese cantidad de equipos (2-20): "; cin>>*c;
                cin.ignore();	
                if(*c<2 || *c>20){
                    cout<<"Error: Dato incorrecto..."<<endl;	
                }
            }while(*c<2 || *c>20);			
            for(int i=0; i<*c; i++){
                cout<<"1. Ingrese nombre de equipo: ";
                cin.getline(equi[i].nom,100);
                do{
                    cout<<"2. Ingrese partidos ganados: ";
                    cin>>equi[i].part_gana;	
                    cin.ignore();
                    if(equi[i].part_gana<0){
                        cout<<"Error: Dato incorrecto..."<<endl;
                    }
                }while(equi[i].part_gana<0);

                equi[i].puntos = equi[i].part_gana * 5;

                do{
                    cout<<"3. Goles a favor: ";
                    cin>>*gol_afa;
                    if(*gol_afa<0){
                        cout<<"Error: Dato incorrecto..."<<endl;
                    }	
                }while(*gol_afa<0);


                    *gol_afato = *gol_afato + *gol_afa;

                do{
                    cout<<"4. Ingrese partidos perdidos: ";
                    cin>>equi[i].part_per;	
                    if(equi[i].part_per<0){
                        cout<<"Error: Dato incorrecto..."<<endl;
                    }
                }while(equi[i].part_per<0);

                do{
                    cout<<"5. Goles en contra: ";
                    cin>>*gol_en;
                    if(*gol_en<0){
                        cout<<"Error: Dato incorrecto..."<<endl;
                    }	
                }while(*gol_en<0);

                    *gol_ento = *gol_ento + *gol_en;

                do{
                    cout<<"6. Ingrese partidos empatados: ";
                    cin>>equi[i].par_emp;
                    cin.ignore();	
                    if(equi[i].par_emp<0){
                        cout<<"Error: Dato incorrecto..."<<endl;
                    }
                }while(equi[i].par_emp<0);

                equi[i].puntos = equi[i].puntos + equi[i].par_emp;
                equi[i].dife = *gol_afa - *gol_en;
                equi[i].porcen = equi[i].part_gana / (equi[i].part_gana+equi[i].part_per+equi[i].par_emp);

                cout<<"|=== INFORMACION CALCULADA ===|"<<endl;
                cout<<"[1]. Puntos obtenidos: "<<equi[i].puntos<<endl;
                cout<<"[2]. Porcentaje de efectividad: "<<equi[i].porcen<<endl;
                cout<<"[3]. Diferencia de goles: "<<equi[i].dife<<endl;
                cout<<"|=============================|"<<endl;
            } break;
        case 2: 
            cout<<"|======= REPORTE =======|"<<endl;
            for(int i=0; i<*c; i++){
                cout<<"[1]. Nombre del equipo: "<<equi[i].nom<<endl;
                cout<<"[2]. Puntos del equipo: "<<equi[i].puntos<<endl;
                cout<<"[3]. Porcentaje de efectividad: "<<equi[i].porcen<<endl;
                cout<<"[4]. Diferencia de goles: "<<equi[i].dife<<endl;
                cout<<"|=============================|"<<endl;
            }

        break;

        case 3:
            cout<<"Hasta luego..."<<endl;
            break;
    }	

    delete gol_afa;
    delete gol_en;
    delete gol_afato;
    delete gol_ento;
    delete[] equi;
    return;
}
