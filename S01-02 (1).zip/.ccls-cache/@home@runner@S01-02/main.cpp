# include <iostream>
using namespace std;
struct nodo{
int dato;
nodo *sig;
};
void encolar(nodo *&cola);
void desencolar(nodo *&cola);
void mostrar(nodo *&cola);
void vaciar(nodo *&cola);
void menu();
void validarmenu();
void registrar(nodo*&p);
void imprimir(nodo*&nuevo);

int main(){
  nodo *cabeza=NULL;
  nodo *cola=NULL;
  
}
void encolar(nodo *cabeza,nodo *cola){
  nodo *nuevo=new nodo;
  registrar(nuevo);
  if(cola!=NULL){
    cola ->sig=nuevo;
    cola=nuevo;
  }else{
    cabeza=nuevo;
    cola=nuevo;
  }cola ->sig=NULL;
  cout<<"nodo encolado:";
  return;
}
void desencolar(nodo *cabeza,nodo *cola){
  nodo*p=cabeza;
  if(cola!=NULL){
    cabeza =p->sig;
    if(cabeza == NULL);
    cola = NULL;
    cout<<"desencolando nodo";
    imprimir(p);
    delete p;
  }else
    cout<<"cola vacia";
  return;
}
void mostrar (nodo *&cabeza);{
nodo *p=cabeza;
if (cabeza != NULL){
  while(p!=NULL){
    imprimir(p);
    p=p->sig;
  }
  cout<<"null";
}else cout<<"no hay cola";
return;
}
void vaciar(nodo *&cabeza,nodo *&cola){
  if(cabeza!=NULL){
    while(cola!=NULL)
      desencolar(cabeza,cola);
    cout<<"cola liberada";
  }else
    cout<<"cola vacia";
  return;
}
void menu(){
    cout<<"menu de opciones----"<<endl;
    cout << "1. Apilar" <<endl;
    cout << "2. Desapilar"<<endl;
    cout << "3. Mostrar"<<endl;
    cout << "4. Vaciar"<<endl;
    cout << "5. Salir"<<endl;
}
void validarmenu (){
    nodo *cola = NULL;
    int op = 0;  
    do {
        menu();
        cout << "Ingrese su opcion: ";
        cin >> op;  
        switch (op) {
            case 1: encolar(cola); break;
            case 2: desencolar(cola); break;
            case 3: mostrar(cola); break;
            case 4: vaciar(cola); break;
            case 5: cout << "Saliendo..." << endl; break;  
            default: cout << "Opcion invalida" << endl; break;  
        }
    } while (op != 5);

    vaciar(cola);
    return;
}

